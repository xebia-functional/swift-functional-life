//: # Looking back at the classics: generic data types on Swift (part 4)

import UIKit

//: ## Binary Search Tree


public class BST<T:Comparable>:Printable{
    
    var data: T?
    var left: BST?
    var right: BST?
    
    init(data:T){
        self.data = data
    }
    
    func search(element:T) -> Bool?{
        println(self.data)
        switch(self.data, self.left, self.right) {
        case (.None, _ ,_):
            return false
        case let (data, _, _) where data == element:
            return true
        case let (data, .Some(l), _) where data > element:
            return l.search(element)
        case let (data, _, .Some(r)) where data < element:
            return self.right?.search(element)
        default:
            return false
        }
    }
    
    func insert(element:T){
        
        switch(self.data, self.left, self.right) {
        case let (.None, _, _):
            self.data = element
        case let (data, .Some(l), _) where data > element:
            l.insert(element)
        case let (data, .None, _) where data > element:
            self.left = BST(data:element)
        case let (data, _, .Some(r)) where data <= element:
            r.insert(element)
        case let (data, _, .None) where data <= element:
            self.right = BST(data:element)
        default:
            println("Error")
        }
    }
    
    func remove(element:T) -> BST?{
        
        switch(self.data, self.left, self.right) {
        case let (.None, _, _):
            return self
        case let (data, .Some(l), _) where data > element:
            self.left = l.remove(element)
        case let (data, _, .Some(r)) where data < element:
            self.right = r.remove(element)
        case let (data, .None, .None) where data == element:
            return .None
        case let (data, .Some(l), .None) where data == element:
            return left
        case let (data, .None, .Some(r)) where data == element:
            return right
        case let (data, .Some(l), .Some(r)) where data == element:
            let a = findMin(self.right!)
            self.data = a?.data
            self.right = r.remove(self.data!)
        default:
            println("Error")
        }
        return self
        
    }
    
    func findMin(var root:BST)-> BST?{
        
        while (root.data != .None) {
            if let left = root.left{
                root = root.left!
            }else{
                return root
            }
        }
        return root
    }

    public var description: String {
        switch (self.data, self.left, self.right) {
        case let (.None, _, _):
            return "."
        case let (data, .Some(l), .Some(r)):
            return "[\(l.description) \(data) \(r.description)]"
        case let (data, .None, .Some(r)):
            return "[(.) \(data) \(r.description)]"
        case let (data, .Some(l), .None):
            return "[\(l.description) \(data) (.)]"
        case let (data, .None, .None):
            return "[(.) \(data) (.)]"
        default:
            return ""
        }
    }
}

//: Example with BST

var bst = BST(data: 6)

var inputArray = [4,8,5,1,3,7,10]

for i in inputArray {
    bst.insert(i)
}
bst.description
bst.left?.description
bst.right?.description

bst.search(10)
let a = bst.remove(8)
a?.description

let b = bst.remove(1)
b?.description


//: ## Enum in BinaryTree

protocol BSTProtocol  {
    mutating func add(Int)-> BSTProtocol
    func search(element:Int)->Bool
}

enum BSTEnum: BSTProtocol,Printable {
    
    case Empty
    case Node(Int, left: BSTProtocol, right: BSTProtocol)
    
    mutating func add(element:Int)-> BSTProtocol {
        switch self {
        case .Empty:
            self = BSTEnum.Node(element, left: BSTEnum.Empty, right: BSTEnum.Empty)
        case var .Node(value, left, right):
            if element > value {
                self = BSTEnum.Node(value, left: left, right: right.add(element))
            } else {
                self = BSTEnum.Node(value, left: left.add(element), right: right)
            }
        }
        return self
    }
    
    func search(element:Int)->Bool{
        
        switch self{
        case .Empty:
            return false
        case let .Node(value, left, right) where element == value:
            return true
        case let .Node(value, left, right) where value > element:
            return left.search(element)
        case let .Node(value, left, right) where value < element:
            return right.search(element)
        default:
            println("Error")
        }
        return false
    }
    
    var description: String {
        switch self {
        case .Empty:
            return "."
        case let .Node(value, left, right):
            return "[\(left) \(value) \(right)]"
        }
    }
    
}


//: Example with Enum BST

var inputArrayEnum = [6,4,8,5,1,3,7,10]
var treeEnum = BSTEnum.Empty
for i in inputArrayEnum {
    treeEnum.add(i)
}

treeEnum.description
