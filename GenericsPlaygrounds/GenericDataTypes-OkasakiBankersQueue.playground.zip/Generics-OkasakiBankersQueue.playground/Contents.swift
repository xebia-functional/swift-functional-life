// Looking back at the classics: generic data types on Swift

import Foundation

// MARK: - Singly-linked list implementation

// We use a class insteand of a struct because Swift forbids using recursive data types (i.e.: using a List property inside of List) in structs.
// There are ways to get around it, but let's keep it simple for the sake of clarity :).
class List<T> {
    let head : T?
    let tail : List<T>?
    let count : Int
    
    init(head: T?, tail: List<T>?) {
        self.head = head
        self.tail = tail
        
        switch (head, tail) {
        case let (.Some(h), .Some(l)): count = l.count + 1
        case let (.Some(h), nil): count = 1
        case let (nil, .Some(l)): count = l.count
        default: count = 0
        }
    }
    
    convenience init() {
        self.init(head: nil, tail: nil)
    }
}

extension List {
    func cons(item: T) -> List {
        return List(head: item, tail: self)
    }
    
    func next() -> List<T>? {
        return tail
    }
}

extension List {
    subscript(index: Int) -> T? {
        if index >= self.count {
            return nil
        }
        var count = 0
        var currentNext = self
        var value : T? = nil
        while(currentNext.next() != nil && count <= index)  {
            if count == index {
                value = currentNext.head
            }
            count++
            currentNext = currentNext.next()!
        }
        return value
    }
}

extension List : Printable {
    var description : String {
        if let h = self.head {
            var descriptionText = "List(\(self.count)): \(self.head!)"
            var next = self.next()
            while (next?.head != nil) {
                descriptionText += ", \(next!.head!)"
                next = next!.next()
            }
            return descriptionText
        } else {
            return "Empty list"
        }
    }
}

// MARK: -  Chris Okasaki's Banker's queue implementation

// We need to add reverse and append operations to our lists:
extension List {
    func reverse() -> List {
        if self.count <= 1 {
            return self
        }
        
        var currentList = self
        var newList = List().cons(currentList.head!)
        while (currentList.next() != nil) {
            currentList = currentList.next()!
            if let h = currentList.head {
                newList = newList.cons(h)
            }
        }
        return newList
    }
}

extension List {
    func append(x: List) -> List {
        switch self.count {
        case 0: return x
        case 1: return List(head: self.head!, tail: x)
        default: return List(head: self.head!, tail: tail!.append(x))
        }
    }
}

// The proper implementation of the queue goes as follows:

struct BankersQueue<T> {
    let front : List<T>
    let rear : List<T>
    let fSize : Int
    let rSize : Int
    
    init(fSize: Int, front: List<T>, rSize: Int, rear: List<T>) {
        self.fSize = fSize
        self.front = front
        self.rSize = rSize
        self.rear = rear
    }
}

extension BankersQueue {
    static func check(bq: BankersQueue) -> BankersQueue {
        if bq.rSize <= bq.fSize {
            return bq
        } else {
            let fSize2 = bq.fSize + bq.rSize
            let front2 = bq.front.append(bq.rear.reverse())
            return BankersQueue(fSize: fSize2, front: front2, rSize: 0, rear: List())
        }
    }
    
    func enqueue(item: T) -> BankersQueue {
        return BankersQueue.check(BankersQueue(fSize: self.fSize, front: self.front, rSize: self.rSize + 1, rear: self.rear.cons(item)))
    }
    
    func dequeue() -> (item: T?, queue: BankersQueue?) {
        switch self.front.count {
        case 0: return (nil, nil)
        default: return (self.front.head!, BankersQueue.check(BankersQueue(fSize: self.fSize - 1, front: front.tail!, rSize: self.rSize, rear: self.rear)))
        }
    }
}

// Using a Banker's Queue:

var bq = BankersQueue<Int>(fSize: 0, front: List(), rSize: 0, rear: List())
bq = bq.enqueue(0)
bq = bq.enqueue(1)
bq = bq.enqueue(2)
bq = bq.enqueue(3)
let tuple = bq.dequeue()
let value = tuple.item
bq = tuple.queue!

tuple.item
tuple.queue
