//: # Looking back at the classics: generic data types on Swift (part 2)

import Foundation

//MARK: - Singly-linked list implementation

/*: ## **Singly-linked list** implementation

We use a class insteand of a struct because Swift forbids using recursive data types (i.e.: using a List property inside of List) in structs.
There are ways to get around it, but let's keep it simple for the sake of clarity :).
*/
class List<T> {
    let head : T?
    let tail : List<T>?
    let count : Int
    
    init(head: T?, tail: List<T>?) {
        self.head = head
        self.tail = tail
        
        switch (head, tail) {
        case let (.Some(h), .Some(l)): count = l.count + 1
        case let (.Some(h), nil): count = 1
        case let (nil, .Some(l)): count = l.count
        default: count = 0
        }
    }
    
    convenience init() {
        self.init(head: nil, tail: nil)
    }
}

extension List {
    func cons(item: T) -> List {
        return List(head: item, tail: self)
    }
    
    func next() -> List<T>? {
        return tail
    }
}

extension List {
    subscript(index: Int) -> T? {
        if index >= self.count {
            return nil
        }
        var count = 0
        var currentNext = self
        var value : T? = nil
        while(currentNext.next() != nil && count <= index)  {
            if count == index {
                value = currentNext.head
            }
            count++
            currentNext = currentNext.next()!
        }
        return value
    }
}

extension List : Printable {
    var description : String {
        if let h = self.head {
            var descriptionText = "List(\(self.count)): \(self.head!)"
            var next = self.next()
            while (next?.head != nil) {
                descriptionText += ", \(next!.head!)"
                next = next!.next()
            }
            return descriptionText
        } else {
            return "Empty list"
        }
    }
}

//: Using a singly-linked list

var list = List<Int>()
list = list.cons(1)
list = list.cons(2)
list = list.cons(3)
list = list.cons(4)


// MARK: - Stack implementation (based on a singly-linked list)
//: ## **Stack** implementation (based on a singly-linked list)
struct Stack<T> {
    private var internalList : List<T>
    
    init() {
        self.internalList = List<T>()
    }
    
    private init(internalList : List<T>?) {
        if let list = internalList {
            self.internalList = list
        } else {
            self.internalList = List()
        }
    }
}

extension Stack {
    func push(item: T) -> Stack {
        return Stack(internalList: internalList.cons(item))
    }
    
    func pop() -> (item: T?, stack: Stack?) {
        return (item: internalList.head, stack: Stack(internalList: internalList.next()))
    }
    
    func top() -> T? {
        return self.internalList.head
    }
    
    var count : Int {
        get {
            return internalList.count
        }
    }
}

extension Stack : Printable {
    var description : String {
        switch self.count {
        case 0: return "Empty Stack"
        default: return "Stack(\(self.count)) top: \(self.top())"
        }
    }
}

//: Using a stack

var stack = Stack<Int>()
stack.description

stack = stack.push(0)
stack.description

stack = stack.push(1)
stack.description

stack.pop().stack?.description
