result = discriminateNumberByFunction(8, "prime", isPrime)   // "This is a really small number"
println(result)
result = discriminateNumberByFunction(5, "prime", isPrime)   // "This is a small but cool prime number"
println(result)
