func sayHelloToPerson(greeting: String, name: String) -> String {
    return greeting + ", " + name
}

sayHelloToPerson("Hello", "Dolly")	// "Hello, Dolly"