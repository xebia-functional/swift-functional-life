let beatInformalGreetings = beatles.map(greetPerson("Good morning"))
println(beatInformalGreetings)
