let fullBeatles = ["John Lennon", "Paul McCartney", "George Harrison", "Ringo Starr", "Brian Epstein", "Stuart Sutcliffe", "Pete Best"]
// Get a list of all former Beatles' surnames!
// Hint: use the map function to return a substring, you can use the find function to get the index of the separator...

let queenMembers = ["Mercury", "May", "Deacon", "Taylor"]
// Try to concatenate all Queen members surnames that start with an "M". Notice that in Swift there's a handy startsWith function!
// You can use filter and reduce, or use reduce alone itself.