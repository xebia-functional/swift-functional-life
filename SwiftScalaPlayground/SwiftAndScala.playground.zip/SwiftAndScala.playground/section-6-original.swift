/*NSURL *dangerousUrl = [NSURL urlWithString:@"troll://not an url"];
if (dangerousUrl) {
	NSString *dangerousString = [dangerousUrl absoluteString];
	if (dangerousString) {
		NSLog([dangerousString uppercaseString])		} 	}
}*/
