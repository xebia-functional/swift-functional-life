potentiallyDangerousUrl?.absoluteString?.uppercaseString
niceUrl?.absoluteString?.uppercaseString
