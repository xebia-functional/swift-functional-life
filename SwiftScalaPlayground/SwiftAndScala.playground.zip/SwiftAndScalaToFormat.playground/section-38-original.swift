let beatleMath = beatles.map({ $0.utf16Count }).reduce(0, combine: +)    // 19
let beatleGreetings = beatInformalGreetings.reduce("", combine: {$0 + "\n" + $1 })
println(beatleMath)
println(beatleGreetings)
